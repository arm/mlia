"""Module to host all file system related functions."""
import shutil
from pathlib import Path
from typing import Any
from typing import Optional

from typing_extensions import Literal

try:
    import importlib.resources as pkg_resources
except ImportError:
    # Try backported to PY<37 `importlib_resources`.
    import importlib_resources as pkg_resources  # type: ignore

ResourceType = Literal["applications", "systems", "tools"]


def get_resources(name: ResourceType) -> Path:
    """Return the absolute path of the specified resource.

    It uses importlib to return resources packaged with MANIFEST.in.
    """
    if not name:
        raise ResourceWarning("Resource name is not provided")

    with pkg_resources.path("aiet", "resources") as base_path:  # type: ignore
        resource_path = Path(base_path) / name
        if resource_path.is_dir():
            return resource_path

    raise ResourceWarning("Resource '{}' not found.".format(name))


def copy_directory_content(source: Path, destination: Path) -> None:
    """Copy content of the source directory into destination directory."""
    for item in source.iterdir():
        src = source / item.name
        dest = destination / item.name

        if src.is_dir():
            shutil.copytree(src, dest)
        else:
            shutil.copy2(src, dest)


def remove_resource(resource_directory: str, resource_type: ResourceType) -> None:
    """Remove resource data."""
    resources = get_resources(resource_type)

    resource_location = resources / resource_directory
    if not resource_location.exists():
        raise Exception("Resource {} does not exist".format(resource_directory))

    if not resource_location.is_dir():
        raise Exception("Wrong resource {}".format(resource_directory))

    shutil.rmtree(resource_location)


def remove_directory(directory_path: Optional[Path]) -> None:
    """Remove directory."""
    if not directory_path or not directory_path.is_dir():
        raise Exception("No directory path provided")

    shutil.rmtree(directory_path)


def recreate_directory(directory_path: Optional[Path]) -> None:
    """Recreate directory."""
    if not directory_path:
        raise Exception("No directory path provided")

    if directory_path.exists() and not directory_path.is_dir():
        raise Exception(
            "Path {} does exist and it is not a directory".format(str(directory_path))
        )

    if directory_path.is_dir():
        remove_directory(directory_path)

    directory_path.mkdir()


def read_file(file_path: Path, mode: Optional[str] = None) -> Any:
    """Read file as string or bytearray."""
    if file_path.is_file():
        if mode is not None:
            with open(file_path, mode) as file:
                return file.read()
        else:
            with open(file_path) as file:
                return file.read()

    if mode == "rb":
        return b""
    return ""


def read_file_as_string(file_path: Path) -> str:
    """Read file as string."""
    return str(read_file(file_path))


def read_file_as_bytearray(file_path: Path) -> bytearray:
    """Read a file as bytearray."""
    return bytearray(read_file(file_path, mode="rb"))
