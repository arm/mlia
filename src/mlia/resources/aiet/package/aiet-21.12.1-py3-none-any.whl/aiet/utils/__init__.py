"""This module contains all utils shared across aiet project."""
